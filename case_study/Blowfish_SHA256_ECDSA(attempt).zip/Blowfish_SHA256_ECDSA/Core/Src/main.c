/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Level-3: Blowfish + ECDSA (planned) + SHA-256 Case Study
  *
  * @details
  * This firmware uses Blowfish for symmetric encryption, SHA-256 for integrity checking,
  * and includes ECDSA signature verification support using the
  * STM32 Cryptographic Library (CryptoLib). Due to middleware integration
  * issues, ECDSA signature checking remains non-functional in this build.
  *
  *
  * © 2025 STMicroelectronics. Provided AS-IS.
  ******************************************************************************
  */
/* USER CODE END Header */

#include "main.h"
#include "com.h"
#include "hashcheck.h"
#include "blowfish.h"
#include "stm32f7xx_hal_rng.h"
#include <stdio.h>
#include <string.h>

#include "firmware_sig.h"
#include "public_key.h"
#include "cmox_crypto.h"  // STM32 CryptoLib header

/* Peripheral Handles --------------------------------------------------------*/
CRC_HandleTypeDef   hcrc;
UART_HandleTypeDef  huart3;
TIM_HandleTypeDef   htim11;
RNG_HandleTypeDef   hrng;

/* USER CODE BEGIN PV */
static const uint32_t BF_KEY[4] = {
  0xABCDEFAB, 0xCDEFABCD,
  0xEFABCDEF, 0xABCDEFAB
};
static const uint32_t BF_TEST[2] = {
  0x12300325, 0x89646238
};

uint32_t bf_ct[2], bf_dt[2];
uint8_t  sha_digest[32];
int32_t  sha_len;
/* USER CODE END PV */

/* Function Prototypes -------------------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_CRC_Init(void);
static void MX_TIM11_Init(void);
static void MX_RNG_Init(void);

int main(void)
{
  BLOWFISH_CTX bf_ctx;
  uint32_t start, stop, elapsed;
  char     uart_buf[80];
  int      uart_len;

  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_USART3_UART_Init();
  MX_CRC_Init();
  MX_TIM11_Init();
  MX_RNG_Init();

  // Initialise COM & do firmware‐integrity check
  COM_Init();
  printf("\r\n=== COM Initialized ===\r\n");
  printf(">>> Verifying FW SHA-256...\r\n");
  FW_Hash_Verify();    // prints pass/fail and loops forever on failure
  printf(">>> FW Hash OK — proceeding to XTEA+SHA benchmark\r\n");

  // ECDSA Signature Verification (planned) ---
  printf(">> Attempting ECDSA signature verification (experimental)\r\n");

  cmox_initialize();

  const uint8_t* pub_key = (const uint8_t*)public_key;
  const uint8_t* sig     = (const uint8_t*)firmware_signature;
  const uint8_t* msg     = (const uint8_t*)firmware_hash; // SHA-256 hash of firmware image

  size_t msg_len = 32;
  size_t sig_len = 64; // ECDSA P-256
  cmox_ecc_retval_t result;

  cmox_ecc_handle_t ecc_ctx;
  cmox_ecc_init(&ecc_ctx);

  result = cmox_ecdsa_verify(
    CMOX_ECC_P256,           // Curve
    &ecc_ctx,                // Context
    pub_key, sizeof(public_key),
    msg, msg_len,
    sig, sig_len
  );

  if (result == CMOX_ECC_SUCCESS)
  {
    printf("  ECDSA Signature VALID \xE2\x9C\x94\r\n\r\n");
  }
  else
  {
    printf("  ECDSA Signature INVALID or check failed\r\n");
    // HALT IF NECESSARY
    // while(1);
  }

  cmox_finalize();

  /* --- Mission Case Study --- */

  // a) Drone Identification: encrypt & decrypt unique ID
  printf(">> Drone ID phase\n");
  uint32_t uid0 = *(uint32_t*)0x1FFF7A10;
  uint32_t uid1 = *(uint32_t*)(0x1FFF7A10+4);
  uint32_t uid2 = *(uint32_t*)(0x1FFF7A10+8);
  printf("  Raw UID: %08lx %08lx %08lx\r\n",
         (unsigned long)uid2,
         (unsigned long)uid1,
         (unsigned long)uid0);

  // encrypt first 64 bits
  uint32_t id_pt[2] = { uid0, uid1 };
  memcpy(&bf_ctx, &(BLOWFISH_CTX){0}, sizeof(bf_ctx));
  Blowfish_Init(&bf_ctx, (uint8_t*)BF_KEY, sizeof(BF_KEY));
  Blowfish_Encrypt(&bf_ctx, &id_pt[0], &id_pt[1]);
  printf("  Encrypted UID: {%08lx %08lx}\r\n", (unsigned long)id_pt[1], (unsigned long)id_pt[0]);

  // decrypt back to verify
  Blowfish_Decrypt(&bf_ctx, &id_pt[0], &id_pt[1]);
  printf("  Decrypted UID: {%08lx %08lx}\r\n\r\n", (unsigned long)id_pt[1], (unsigned long)id_pt[0]);

  // b) Car-plate identification: random 6-digits
  printf(">> Car-plate phase\n");
  uint32_t rnd;
  HAL_RNG_GenerateRandomNumber(&hrng, &rnd);
  uint32_t plate = rnd % 1000000;        // 0..999999
  printf("  Plain plate: %06lu\r\n", (unsigned long)plate);

  // encrypt
  uint32_t plate_pt[2] = { 0, plate };   // pad high-word
  Blowfish_Encrypt(&bf_ctx, &plate_pt[0], &plate_pt[1]);
  printf("  Encrypted plate: {%08lx %08lx}\r\n", (unsigned long)plate_pt[1], (unsigned long)plate_pt[0]);

  // decrypt
  memcpy(&bf_dt, plate_pt, sizeof(plate_pt));
  Blowfish_Decrypt(&bf_ctx, &bf_dt[0], &bf_dt[1]);
  uint32_t recovered = bf_dt[1];
  printf("  Decrypted plate: %06lu\r\n\r\n", (unsigned long)recovered);

  // c) Secret message phase
  printf(">> Secret message phase\n");
  // bytes for "Amazing Ost \o/ " (16 B)
  uint8_t secret_bytes[16] = {
    0x41,0x6D,0x61,0x7A,0x69,0x6E,0x67,0x20,
    0x4F,0x73,0x74,0x20,0x5C,0x6F,0x2F,0x20
  };
  // encrypt in two 64-bit chunks
  uint32_t msg1[2], msg2[2];
  memcpy(msg1, secret_bytes,    8);
  memcpy(msg2, secret_bytes+8,  8);
  Blowfish_Encrypt(&bf_ctx, &msg1[0], &msg1[1]);
  Blowfish_Encrypt(&bf_ctx, &msg2[0], &msg2[1]);
  printf("  Encrypted secret:\r\n"
         "    block1: {%08lx %08lx}\r\n"
         "    block2: {%08lx %08lx}\r\n",
         (unsigned long)msg1[1], (unsigned long)msg1[0],
         (unsigned long)msg2[1], (unsigned long)msg2[0]);

  // decrypt back and print ASCII
  Blowfish_Decrypt(&bf_ctx, &msg1[0], &msg1[1]);
  Blowfish_Decrypt(&bf_ctx, &msg2[0], &msg2[1]);
  char secret[17] = {0};
  memcpy(secret,    msg1, 8);
  memcpy(secret+8, msg2, 8);
  printf("  Secret message: \"%s\"\r\n\r\n", secret);

  HAL_Delay(1000);

  /* --- Performance harness: Blowfish + SHA-256 --- */

  printf(">> Benchmark phase\r\n");
  // one-off test
  memcpy(&bf_ctx, &(BLOWFISH_CTX){0}, sizeof(bf_ctx));
  Blowfish_Init(&bf_ctx, (uint8_t*)BF_KEY, sizeof(BF_KEY));
  memcpy(bf_ct, BF_TEST, sizeof(bf_ct));
  Blowfish_Encrypt(&bf_ctx, &bf_ct[0], &bf_ct[1]);
  memcpy(bf_dt, bf_ct, sizeof(bf_dt));
  Blowfish_Decrypt(&bf_ctx, &bf_dt[0], &bf_dt[1]);
  printf("  BF test CT: {%08lx %08lx}\r\n", (unsigned long)bf_ct[1], (unsigned long)bf_ct[0]);
  printf("  BF test PT: {%08lx %08lx}\r\n\r\n", (unsigned long)bf_dt[1], (unsigned long)bf_dt[0]);
  HAL_Delay(500);


}


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 96;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Activate the Over-Drive mode
  */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief CRC Initialization Function
  * @param None
  * @retval None
  */
static void MX_CRC_Init(void)
{

  /* USER CODE BEGIN CRC_Init 0 */

  /* USER CODE END CRC_Init 0 */

  /* USER CODE BEGIN CRC_Init 1 */

  /* USER CODE END CRC_Init 1 */
  hcrc.Instance = CRC;
  hcrc.Init.DefaultPolynomialUse = DEFAULT_POLYNOMIAL_ENABLE;
  hcrc.Init.DefaultInitValueUse = DEFAULT_INIT_VALUE_ENABLE;
  hcrc.Init.InputDataInversionMode = CRC_INPUTDATA_INVERSION_NONE;
  hcrc.Init.OutputDataInversionMode = CRC_OUTPUTDATA_INVERSION_DISABLE;
  hcrc.InputDataFormat = CRC_INPUTDATA_FORMAT_BYTES;
  if (HAL_CRC_Init(&hcrc) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN CRC_Init 2 */

  /* USER CODE END CRC_Init 2 */

}

/**
  * @brief RNG Initialization Function
  * @param None
  * @retval None
  */
static void MX_RNG_Init(void)
{

  /* USER CODE BEGIN RNG_Init 0 */

  /* USER CODE END RNG_Init 0 */

  /* USER CODE BEGIN RNG_Init 1 */

  /* USER CODE END RNG_Init 1 */
  hrng.Instance = RNG;
  if (HAL_RNG_Init(&hrng) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN RNG_Init 2 */

  /* USER CODE END RNG_Init 2 */

}

/**
  * @brief TIM11 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM11_Init(void)
{

  /* USER CODE BEGIN TIM11_Init 0 */

  /* USER CODE END TIM11_Init 0 */

  /* USER CODE BEGIN TIM11_Init 1 */

  /* USER CODE END TIM11_Init 1 */
  htim11.Instance = TIM11;
  htim11.Init.Prescaler = 95;
  htim11.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim11.Init.Period = 65535;
  htim11.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim11.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim11) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM11_Init 2 */

  /* USER CODE END TIM11_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LED3_GPIO_Port, LED3_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : LED3_Pin */
  GPIO_InitStruct.Pin = LED3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED3_GPIO_Port, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */

/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
