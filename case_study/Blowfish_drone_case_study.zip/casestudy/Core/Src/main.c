/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Level-3: Blowfish + Firmware-Integrity + Mission Case Study
  ******************************************************************************
  * This firmware shows lightweight encryption using Blowfish with firmware integrity
  * through SHA-256.
  *
  * Three phases are simulated:
  *   a) Secure drone identification using encrypted STM32F7 board ID
  *   b) Randomised number plate generation and encryption
  *   c) Transmission of an encrypted secret message
  *
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "com.h"           // COM_Init(), printf()
#include "hashcheck.h"     // FW_Hash_Verify()
#include "blowfish.h"      // Blowfish_Init, Encrypt/Decrypt
#include "stm32f7xx_hal_rng.h"
#include <stdio.h>
#include <string.h>



/* Private variables ---------------------------------------------------------*/
CRC_HandleTypeDef   hcrc;
UART_HandleTypeDef  huart3;
TIM_HandleTypeDef   htim11;
RNG_HandleTypeDef   hrng;

/* USER CODE BEGIN PV */
// 128-bit Blowfish key + test block
static const uint32_t BF_KEY[4] = {
  0xABCDEFAB, 0xCDEFABCD,
  0xEFABCDEF, 0xABCDEFAB
};

// Test block for encryption timing
static const uint32_t BF_TEST[2] = {
  0x12300325, 0x89646238
};

// Encryption and Decryption buffers
uint32_t bf_ct[2], bf_dt[2];

// Buffer for SHA-256 digest
uint8_t  sha_digest[32];
int32_t  sha_len;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_CRC_Init(void);
static void MX_TIM11_Init(void);
static void MX_RNG_Init(void);

/* USER CODE BEGIN 0 */
/* Retarget printf to UART3 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  */
int main(void)
{
  BLOWFISH_CTX bf_ctx;
  uint32_t start, stop, elapsed;
  char     uart_buf[80];
  int      uart_len;

  /* MCU init */
  HAL_Init();
  SystemClock_Config();

  /* Peripherals init */
  MX_GPIO_Init();
  MX_USART3_UART_Init();
  MX_CRC_Init();
  MX_TIM11_Init();
  MX_RNG_Init();

  COM_Init();

  // Firmware Hash verification
  printf("\r\n=== COM Initialized ===\r\n");
  printf(">>> Verifying FW SHA-256...\r\n");
  FW_Hash_Verify();    // loops forever on failure
  printf(">>> FW Hash OK — proceeding to Blowfish+SHA benchmark\r\n");

  /* --- Mission Case Study --- */

  // Drone Identification: encrypt 96-bit UID using HAL
  printf(">> Drone ID phase (HAL UID Read)\r\n");

   uint32_t uid[3];
   uid[0] = HAL_GetUIDw0();
   uid[1] = HAL_GetUIDw1();
   uid[2] = HAL_GetUIDw2();


   printf("  UID (96-bit): %08lx %08lx %08lx\r\n",
          (unsigned long)uid[2],
          (unsigned long)uid[1],
          (unsigned long)uid[0]);

   // Prepare two 64-bit blocks: {uid[1], uid[0]} and {uid[2], 0}
   uint32_t uid_block1[2] = { uid[0], uid[1] };
   uint32_t uid_block2[2] = { 0x00000000, uid[2] };  // padded

   // Encrypt both blocks
   memcpy(&bf_ctx, &(BLOWFISH_CTX){0}, sizeof(bf_ctx));
   Blowfish_Init(&bf_ctx, (uint8_t*)BF_KEY, sizeof(BF_KEY));
   Blowfish_Encrypt(&bf_ctx, &uid_block1[0], &uid_block1[1]);
   Blowfish_Encrypt(&bf_ctx, &uid_block2[0], &uid_block2[1]);

   printf("  Encrypted UID block 1: {%08lx %08lx}\r\n",
          (unsigned long)uid_block1[1],
          (unsigned long)uid_block1[0]);
   printf("  Encrypted UID block 2: {%08lx %08lx}\r\n",
          (unsigned long)uid_block2[1],
          (unsigned long)uid_block2[0]);

   // Decrypt both blocks (commented out - uncomment for board-based decryption)
   //Blowfish_Decrypt(&bf_ctx, &uid_block1[0], &uid_block1[1]);
   //Blowfish_Decrypt(&bf_ctx, &uid_block2[0], &uid_block2[1]);

   //printf("  Decrypted UID (96-bit): %08lx %08lx %08lx\r\n\r\n",
          //(unsigned long)uid_block2[1],
          //(unsigned long)uid_block1[1],
          //(unsigned long)uid_block1[0]);

  // Car-plate identification: random 6-digits
  printf(">> Car-plate phase\r\n");
  uint32_t rnd;
  HAL_RNG_GenerateRandomNumber(&hrng, &rnd);
  uint32_t plate = rnd % 1000000;

  printf("  Plain plate: %06lu\r\n", (unsigned long)plate);

  // encrypt
  uint32_t plate_pt[2] = { 0, plate };   // pad high-word
  Blowfish_Encrypt(&bf_ctx, &plate_pt[0], &plate_pt[1]);
  printf("  Encrypted plate: {%08lx %08lx}\r\n", (unsigned long)plate_pt[1], (unsigned long)plate_pt[0]);

  // decrypt plate (commented out - uncomment for board-based decryption)
  //memcpy(&bf_dt, plate_pt, sizeof(plate_pt));
  //Blowfish_Decrypt(&bf_ctx, &bf_dt[0], &bf_dt[1]);
  //uint32_t recovered = bf_dt[1];
  //printf("  Decrypted plate: %06lu\r\n\r\n", (unsigned long)recovered);

  // Secret message phase
  printf(">> Secret message phase\r\n");

  // bytes for "Amazing Ost \o/ " (16 B)
  uint8_t secret_bytes[16] = {
    0x41,0x6D,0x61,0x7A,0x69,0x6E,0x67,0x20,
    0x4F,0x73,0x74,0x20,0x5C,0x6F,0x2F,0x20
  };

  // encrypt in two 64-bit chunks
  uint32_t msg1[2], msg2[2];
  memcpy(msg1, secret_bytes,    8);
  memcpy(msg2, secret_bytes+8,  8);

  Blowfish_Encrypt(&bf_ctx, &msg1[0], &msg1[1]);
  Blowfish_Encrypt(&bf_ctx, &msg2[0], &msg2[1]);

  printf("  Encrypted secret:\r\n"
         "    block1: {%08lx %08lx}\r\n"
         "    block2: {%08lx %08lx}\r\n",
         (unsigned long)msg1[1], (unsigned long)msg1[0],
         (unsigned long)msg2[1], (unsigned long)msg2[0]);

  // Decrypt message (commented out - uncomment for board-based decryption)
  //Blowfish_Decrypt(&bf_ctx, &msg1[0], &msg1[1]);
  //Blowfish_Decrypt(&bf_ctx, &msg2[0], &msg2[1]);
  //char secret[17] = {0};
  //memcpy(secret,    msg1, 8);
  //memcpy(secret+8, msg2, 8);
  //printf("  Secret message: \"%s\"\r\n\r\n", secret);

  HAL_Delay(1000);

}


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 96;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Activate the Over-Drive mode
  */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief CRC Initialization Function
  * @param None
  * @retval None
  */
static void MX_CRC_Init(void)
{

  /* USER CODE BEGIN CRC_Init 0 */

  /* USER CODE END CRC_Init 0 */

  /* USER CODE BEGIN CRC_Init 1 */

  /* USER CODE END CRC_Init 1 */
  hcrc.Instance = CRC;
  hcrc.Init.DefaultPolynomialUse = DEFAULT_POLYNOMIAL_ENABLE;
  hcrc.Init.DefaultInitValueUse = DEFAULT_INIT_VALUE_ENABLE;
  hcrc.Init.InputDataInversionMode = CRC_INPUTDATA_INVERSION_NONE;
  hcrc.Init.OutputDataInversionMode = CRC_OUTPUTDATA_INVERSION_DISABLE;
  hcrc.InputDataFormat = CRC_INPUTDATA_FORMAT_BYTES;
  if (HAL_CRC_Init(&hcrc) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN CRC_Init 2 */

  /* USER CODE END CRC_Init 2 */

}

/**
  * @brief RNG Initialization Function
  * @param None
  * @retval None
  */
static void MX_RNG_Init(void)
{

  /* USER CODE BEGIN RNG_Init 0 */

  /* USER CODE END RNG_Init 0 */

  /* USER CODE BEGIN RNG_Init 1 */

  /* USER CODE END RNG_Init 1 */
  hrng.Instance = RNG;
  if (HAL_RNG_Init(&hrng) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN RNG_Init 2 */

  /* USER CODE END RNG_Init 2 */

}

/**
  * @brief TIM11 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM11_Init(void)
{

  /* USER CODE BEGIN TIM11_Init 0 */

  /* USER CODE END TIM11_Init 0 */

  /* USER CODE BEGIN TIM11_Init 1 */

  /* USER CODE END TIM11_Init 1 */
  htim11.Instance = TIM11;
  htim11.Init.Prescaler = 95;
  htim11.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim11.Init.Period = 65535;
  htim11.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim11.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim11) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM11_Init 2 */

  /* USER CODE END TIM11_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LED3_GPIO_Port, LED3_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : LED3_Pin */
  GPIO_InitStruct.Pin = LED3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED3_GPIO_Port, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */

/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
